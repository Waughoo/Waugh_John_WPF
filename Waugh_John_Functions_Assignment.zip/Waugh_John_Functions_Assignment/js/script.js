// Functions Assignment

// Trying to figure out how many pounds of food my children eat in a week.

var Kids =7; //Number of kids I have
var Variety = 15; //How many different kinds of food there are
var Food = 1.3333333333; //How much each food item ways.
var Type = (Variety * Food); //Fomula for figuring out the amount
var CalcPounds = Kids * Type; //Final formlua
console.log("My " + Kids + " kids eat a combined total of " + CalcPounds + "lbs. of food each week. At this rate, they will eat me out of house and home.")// If you had seven kids, you would feel the same way

function CalcPounds(K, T){
	return Pounds
}

// Trying to do a anonymous function

// I am going to try an anonymous function

var calcCube = function(length, width, height){//let's try some math
	var cube = length * width * height;// formula for a cube
	return cube
}
var CalcCube = calcCube(25, 15, 43);//invoking

console.log("The area of the cube is " + CalcCube)